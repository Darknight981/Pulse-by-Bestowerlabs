"""Signal Aggregator Agent - Combines all agent signals"""
from .base import BaseAgent
from typing import Dict, Any, List
from datetime import datetime, timedelta


class SignalAggregatorAgent(BaseAgent):
    """Aggregates signals from all agents into final recommendation"""
    
    def __init__(self):
        super().__init__("Signal Aggregator", "aggregator")
        
        # Agent weights (importance)
        self.agent_weights = {
            "Market Data Agent": 1.0,
            "Technical Analysis Agent": 1.2,
            "Sentiment Analysis Agent": 0.9,
            "News Analysis Agent": 0.9,
            "Macro Economic Agent": 1.0,
            "Geopolitical Risk Agent": 0.8,
            "Whale Activity Agent": 1.1,
            "Volume & Liquidity Agent": 1.0,
            "Correlation Agent": 0.7,
            "Risk Management Agent": 1.1
        }
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Aggregate all agent signals"""
        symbol = context.get("symbol", "BTC")
        agent_outputs = context.get("agent_outputs", [])
        
        if not agent_outputs:
            return {
                "confidence": 50,
                "analysis": "No agent outputs to aggregate.",
                "data": {"signal": "hold", "confidence": 50}
            }
        
        # Calculate weighted sentiment
        bullish_score = 0
        bearish_score = 0
        total_weight = 0
        contributing_agents = []
        
        for output in agent_outputs:
            agent_name = output.get("agent_name", "")
            weight = self.agent_weights.get(agent_name, 1.0)
            confidence = output.get("confidence", 50) / 100
            data = output.get("data", {})
            
            # Extract signal from agent data
            signal = data.get("signal", "")
            overall = data.get("overall", "")
            trend = data.get("trend", "")
            
            # Determine direction
            bullish_signals = ["buy", "bullish", "accumulation", "oversold_bullish", "strong_bullish_confirmd"]
            bearish_signals = ["sell", "bearish", "distribution", "overbought_bearish", "strong_bearish_confirmed"]
            
            is_bullish = any(s in str(signal).lower() for s in bullish_signals)
            is_bullish = is_bullish or any(s in str(overall).lower() for s in bullish_signals)
            is_bullish = is_bullish or any(s in str(trend).lower() for s in bullish_signals)
            
            is_bearish = any(s in str(signal).lower() for s in bearish_signals)
            is_bearish = is_bearish or any(s in str(overall).lower() for s in bearish_signals)
            is_bearish = is_bearish or any(s in str(trend).lower() for s in bearish_signals)
            
            if is_bullish:
                bullish_score += weight * confidence
                contributing_agents.append(f"{agent_name}: bullish")
            elif is_bearish:
                bearish_score += weight * confidence
                contributing_agents.append(f"{agent_name}: bearish")
            else:
                contributing_agents.append(f"{agent_name}: neutral")
            
            total_weight += weight
        
        # Calculate final signal
        if total_weight > 0:
            bullish_pct = bullish_score / total_weight
            bearish_pct = bearish_score / total_weight
        else:
            bullish_pct = 0
            bearish_pct = 0
        
        # Determine signal
        if bullish_pct > bearish_pct * 1.5 and bullish_pct > 0.4:
            signal = "buy"
            confidence = min(95, int(bullish_pct * 100))
        elif bearish_pct > bullish_pct * 1.5 and bearish_pct > 0.4:
            signal = "sell"
            confidence = min(95, int(bearish_pct * 100))
        elif bullish_pct > 0.3:
            signal = "weak_buy"
            confidence = int(bullish_pct * 100)
        elif bearish_pct > 0.3:
            signal = "weak_sell"
            confidence = int(bearish_pct * 100)
        else:
            signal = "hold"
            confidence = 50
        
        # Strong signal override
        if bullish_pct > 0.6:
            signal = "strong_buy"
        elif bearish_pct > 0.6:
            signal = "strong_sell"
        
        analysis = f"""
        Signal Aggregation for {symbol}:
        - Bullish Score: {bullish_score:.2f}
        - Bearish Score: {bearish_score:.2f}
        - Bullish %: {bullish_pct*100:.1f}%
        - Bearish %: {bearish_pct*100:.1f}%
        - Final Signal: {signal}
        - Confidence: {confidence}%
        - Contributing Agents: {len(contributing_agents)}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "signal": signal,
                "confidence": confidence,
                "bullish_score": bullish_score,
                "bearish_score": bearish_score,
                "bullish_pct": bullish_pct,
                "bearish_pct": bearish_pct,
                "contributing_agents": contributing_agents
            }
        }
