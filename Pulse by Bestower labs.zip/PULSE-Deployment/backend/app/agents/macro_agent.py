"""Macro Economic Agent - Analyzes macroeconomic conditions"""
from .base import BaseAgent
from typing import Dict, Any
from datetime import datetime


class MacroEconomicAgent(BaseAgent):
    """Analyzes macroeconomic factors affecting markets"""
    
    def __init__(self):
        super().__init__("Macro Economic Agent", "macro")
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze macro conditions"""
        symbol = context.get("symbol", "BTC")
        asset_type = context.get("asset_type", "crypto")
        macro_events = context.get("macro_events", [])
        
        # Analyze relevant macro factors
        fed_events = [e for e in macro_events if "fed" in e.get("title", "").lower()]
        inflation_events = [e for e in macro_events if any(kw in e.get("title", "").lower() 
                          for kw in ["inflation", "cpi"])]
        
        # Determine macro environment
        if fed_events:
            latest_fed = fed_events[0]
            if "hike" in latest_fed.get("title", "").lower():
                fed_stance = "hawkish"
                rate_signal = "bearish_for_risk_assets"
            elif "cut" in latest_fed.get("title", "").lower():
                fed_stance = "dovish"
                rate_signal = "bullish_for_risk_assets"
            else:
                fed_stance = "neutral"
                rate_signal = "neutral"
        else:
            fed_stance = "neutral"
            rate_signal = "neutral"
        
        # Inflation impact
        if inflation_events:
            latest_cpi = inflation_events[0]
            if "high" in latest_cpi.get("title", "").lower() or "up" in latest_cpi.get("title", "").lower():
                inflation_trend = "rising"
                inflation_signal = "bearish_short_term"
            else:
                inflation_trend = "stable_falling"
                inflation_signal = "bullish"
        else:
            inflation_trend = "stable"
            inflation_signal = "neutral"
        
        # Overall macro signal
        if asset_type == "crypto":
            # Crypto is sensitive to rates
            if fed_stance == "hawkish":
                overall = "bearish"
                confidence = 70
            elif fed_stance == "dovish":
                overall = "bullish"
                confidence = 70
            else:
                overall = "neutral"
                confidence = 50
        else:
            # Stocks
            if fed_stance == "dovish" and inflation_trend == "stable_falling":
                overall = "bullish"
                confidence = 75
            elif fed_stance == "hawkish":
                overall = "cautious"
                confidence = 65
            else:
                overall = "neutral"
                confidence = 55
        
        analysis = f"""
        Macro Economic Analysis:
        - Fed Stance: {fed_stance}
        - Rate Signal: {rate_signal}
        - Inflation Trend: {inflation_trend}
        - Inflation Signal: {inflation_signal}
        - Overall Macro: {overall}
        - Active Macro Events: {len(macro_events)}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "fed_stance": fed_stance,
                "rate_signal": rate_signal,
                "inflation_trend": inflation_trend,
                "inflation_signal": inflation_signal,
                "overall": overall,
                "active_events": len(macro_events)
            }
        }
