"""Technical Analysis Service - Indicators and calculations"""
import numpy as np
import pandas as pd
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class TechnicalAnalysisService:
    """Calculate technical indicators"""
    
    @staticmethod
    def calculate_sma(prices: List[float], period: int) -> List[float]:
        """Simple Moving Average"""
        if len(prices) < period:
            return [np.nan] * len(prices)
        return pd.Series(prices).rolling(window=period).mean().tolist()
    
    @staticmethod
    def calculate_ema(prices: List[float], period: int) -> List[float]:
        """Exponential Moving Average"""
        if len(prices) < period:
            return [np.nan] * len(prices)
        return pd.Series(prices).ewm(span=period, adjust=False).mean().tolist()
    
    @staticmethod
    def calculate_rsi(prices: List[float], period: int = 14) -> List[float]:
        """Relative Strength Index"""
        if len(prices) < period + 1:
            return [50.0] * len(prices)
            
        deltas = np.diff(prices)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        
        avg_gains = pd.Series(gains).rolling(window=period).mean()
        avg_losses = pd.Series(losses).rolling(window=period).mean()
        
        rs = avg_gains / avg_losses
        rsi = 100 - (100 / (1 + rs))
        
        # Pad with neutral values
        rsi = [50.0] + rsi.tolist()
        return rsi
    
    @staticmethod
    def calculate_macd(prices: List[float], fast: int = 12, slow: int = 26, signal: int = 9) -> Dict:
        """MACD indicator"""
        if len(prices) < slow:
            return {"macd": [0], "signal": [0], "histogram": [0]}
            
        ema_fast = pd.Series(prices).ewm(span=fast, adjust=False).mean()
        ema_slow = pd.Series(prices).ewm(span=slow, adjust=False).mean()
        
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal, adjust=False).mean()
        histogram = macd_line - signal_line
        
        return {
            "macd": macd_line.tolist(),
            "signal": signal_line.tolist(),
            "histogram": histogram.tolist()
        }
    
    @staticmethod
    def calculate_bollinger_bands(prices: List[float], period: int = 20, std_dev: float = 2.0) -> Dict:
        """Bollinger Bands"""
        if len(prices) < period:
            return {"upper": prices, "middle": prices, "lower": prices}
            
        sma = pd.Series(prices).rolling(window=period).mean()
        rolling_std = pd.Series(prices).rolling(window=period).std()
        
        upper_band = sma + (rolling_std * std_dev)
        lower_band = sma - (rolling_std * std_dev)
        
        return {
            "upper": upper_band.tolist(),
            "middle": sma.tolist(),
            "lower": lower_band.tolist()
        }
    
    @staticmethod
    def calculate_atr(highs: List[float], lows: List[float], closes: List[float], period: int = 14) -> List[float]:
        """Average True Range"""
        if len(highs) < 2:
            return [0] * len(highs)
            
        highs = pd.Series(highs)
        lows = pd.Series(lows)
        closes = pd.Series(closes)
        
        tr1 = highs - lows
        tr2 = abs(highs - closes.shift(1))
        tr3 = abs(lows - closes.shift(1))
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=period).mean()
        
        return atr.tolist()
    
    @staticmethod
    def calculate_stochastic(highs: List[float], lows: List[float], closes: List[float], 
                            k_period: int = 14, d_period: int = 3) -> Dict:
        """Stochastic Oscillator"""
        if len(highs) < k_period:
            return {"k": [50], "d": [50]}
            
        highs = pd.Series(highs)
        lows = pd.Series(lows)
        closes = pd.Series(closes)
        
        lowest_low = lows.rolling(window=k_period).min()
        highest_high = highs.rolling(window=k_period).max()
        
        k = 100 * ((closes - lowest_low) / (highest_high - lowest_low))
        d = k.rolling(window=d_period).mean()
        
        return {"k": k.tolist(), "d": d.tolist()}
    
    @staticmethod
    def calculate_volume_profile(volumes: List[float], prices: List[float], bins: int = 10) -> Dict:
        """Volume Profile"""
        if len(volumes) != len(prices) or len(volumes) == 0:
            return {"levels": [], "volumes": []}
            
        price_range = max(prices) - min(prices)
        bin_size = price_range / bins if price_range > 0 else 1
        
        profile = {}
        for price, vol in zip(prices, volumes):
            level = int((price - min(prices)) / bin_size) * bin_size + min(prices)
            profile[level] = profile.get(level, 0) + vol
            
        return {
            "levels": list(profile.keys()),
            "volumes": list(profile.values())
        }
    
    @staticmethod
    def find_support_resistance(prices: List[float], window: int = 5) -> Tuple[List[float], List[float]]:
        """Find support and resistance levels"""
        if len(prices) < window * 2 + 1:
            return [], []
            
        prices = np.array(prices)
        supports = []
        resistances = []
        
        for i in range(window, len(prices) - window):
            # Check for local minimum (support)
            if all(prices[i] <= prices[i-j] for j in range(1, window+1)) and \
               all(prices[i] <= prices[i+j] for j in range(1, window+1)):
                supports.append(prices[i])
                
            # Check for local maximum (resistance)
            if all(prices[i] >= prices[i-j] for j in range(1, window+1)) and \
               all(prices[i] >= prices[i+j] for j in range(1, window+1)):
                resistances.append(prices[i])
        
        # Cluster nearby levels
        def cluster_levels(levels: List[float], threshold: float = 0.02) -> List[float]:
            if not levels:
                return []
            levels = sorted(levels)
            clustered = [levels[0]]
            for level in levels[1:]:
                if abs(level - clustered[-1]) / clustered[-1] > threshold:
                    clustered.append(level)
            return clustered[-5:]  # Return last 5 levels
        
        return cluster_levels(supports), cluster_levels(resistances)
    
    @staticmethod
    def analyze_trend(prices: List[float], short_period: int = 20, long_period: int = 50) -> str:
        """Analyze price trend"""
        if len(prices) < long_period:
            return "neutral"
            
        sma_short = pd.Series(prices).rolling(window=short_period).mean().iloc[-1]
        sma_long = pd.Series(prices).rolling(window=long_period).mean().iloc[-1]
        
        current_price = prices[-1]
        
        if current_price > sma_short > sma_long:
            return "strong_uptrend"
        elif current_price > sma_short:
            return "uptrend"
        elif current_price < sma_short < sma_long:
            return "strong_downtrend"
        elif current_price < sma_short:
            return "downtrend"
        else:
            return "sideways"
    
    @staticmethod
    def generate_signals(ohlcv: List[Dict]) -> Dict:
        """Generate trading signals from technical analysis"""
        if len(ohlcv) < 50:
            return {"signal": "neutral", "confidence": 50}
            
        closes = [c["close"] for c in ohlcv]
        highs = [c["high"] for c in ohlcv]
        lows = [c["low"] for c in ohlcv]
        volumes = [c["volume"] for c in ohlcv]
        
        # Calculate indicators
        rsi = TechnicalAnalysisService.calculate_rsi(closes)[-1]
        macd = TechnicalAnalysisService.calculate_macd(closes)
        bb = TechnicalAnalysisService.calculate_bollinger_bands(closes)
        trend = TechnicalAnalysisService.analyze_trend(closes)
        
        # Generate signal
        signals = []
        
        # RSI signals
        if rsi < 30:
            signals.append(("oversold", 1))
        elif rsi > 70:
            signals.append(("overbought", -1))
            
        # MACD signals
        macd_line = macd["macd"][-1]
        signal_line = macd["signal"][-1]
        if macd_line > signal_line and macd["histogram"][-1] > 0:
            signals.append(("macd_bullish", 1))
        elif macd_line < signal_line and macd["histogram"][-1] < 0:
            signals.append(("macd_bearish", -1))
            
        # Trend signals
        if "uptrend" in trend:
            signals.append(("trend_bullish", 1))
        elif "downtrend" in trend:
            signals.append(("trend_bearish", -1))
            
        # Bollinger Bands
        current_price = closes[-1]
        if current_price < bb["lower"][-1]:
            signals.append(("bb_oversold", 1))
        elif current_price > bb["upper"][-1]:
            signals.append(("bb_overbought", -1))
        
        # Calculate overall signal
        score = sum(s[1] for s in signals)
        
        if score >= 2:
            signal = "buy"
        elif score <= -2:
            signal = "sell"
        else:
            signal = "hold"
            
        confidence = min(95, 50 + abs(score) * 15)
        
        return {
            "signal": signal,
            "confidence": confidence,
            "rsi": rsi,
            "macd": macd_line,
            "trend": trend,
            "signals": [s[0] for s in signals],
            "score": score
        }


# Singleton instance
ta_service = TechnicalAnalysisService()
