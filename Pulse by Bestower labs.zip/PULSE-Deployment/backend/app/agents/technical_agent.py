"""Technical Analysis Agent - Analyzes technical indicators"""
from .base import BaseAgent
from typing import Dict, Any
from datetime import datetime


class TechnicalAnalysisAgent(BaseAgent):
    """Analyzes technical indicators and chart patterns"""
    
    def __init__(self):
        super().__init__("Technical Analysis Agent", "technical")
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze technical indicators"""
        symbol = context.get("symbol", "BTC")
        technicals = context.get("technicals", {})
        
        rsi = technicals.get("rsi", 50)
        trend = technicals.get("trend", "neutral")
        signals = technicals.get("signals", [])
        
        # Analyze RSI
        if rsi < 30:
            rsi_signal = "oversold_bullish"
            rsi_confidence = 70
        elif rsi > 70:
            rsi_signal = "overbought_bearish"
            rsi_confidence = 70
        elif rsi < 45:
            rsi_signal = "weak_bearish"
            rsi_confidence = 55
        elif rsi > 55:
            rsi_signal = "weak_bullish"
            rsi_confidence = 55
        else:
            rsi_signal = "neutral"
            rsi_confidence = 50
        
        # Analyze trend
        trend_strength = 50
        if "strong" in trend:
            trend_strength = 80
        elif trend != "neutral":
            trend_strength = 65
        
        # Overall technical signal
        if "buy" in signals or rsi_signal == "oversold_bullish":
            overall_signal = "bullish"
            confidence = max(rsi_confidence, trend_strength)
        elif "sell" in signals or rsi_signal == "overbought_bearish":
            overall_signal = "bearish"
            confidence = max(rsi_confidence, trend_strength)
        else:
            overall_signal = "neutral"
            confidence = 50
        
        analysis = f"""
        Technical Analysis for {symbol}:
        - RSI: {rsi:.1f} ({rsi_signal})
        - Trend: {trend}
        - Signals: {', '.join(signals) if signals else 'none'}
        - Overall: {overall_signal}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "rsi": rsi,
                "trend": trend,
                "rsi_signal": rsi_signal,
                "overall_signal": overall_signal,
                "signals": signals
            }
        }
