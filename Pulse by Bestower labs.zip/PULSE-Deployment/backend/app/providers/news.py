"""News Provider - Financial and crypto news with sentiment"""
import httpx
import asyncio
import feedparser
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
import logging
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

logger = logging.getLogger(__name__)


class NewsProvider:
    """Financial news with sentiment analysis"""
    
    RSS_FEEDS = {
        "reuters": "https://www.reutersagency.com/feed/?best-topics=business-finance",
        "coindesk": "https://www.coindesk.com/arc/outboundfeeds/rss/",
        "cointelegraph": "https://cointelegraph.com/rss",
        "cryptonews": "https://cryptonews.com/news/feed",
    }
    
    CRYPTO_KEYWORDS = [
        "bitcoin", "btc", "ethereum", "eth", "crypto", "cryptocurrency", 
        "blockchain", "altcoin", "defi", "nft", "binance", "coinbase",
        "solana", "sol", "cardano", "ada", "ripple", "xrp", "polygon",
        "matic", "chainlink", "link", "uniswap", "litecoin", "ltc"
    ]
    
    STOCK_KEYWORDS = [
        "stock", "equity", "shares", "trading", "market", "nasdaq", "nyse",
        "sp500", "dow", "apple", "microsoft", "google", "amazon", "tesla",
        "meta", "nvidia", "earnings", "dividend", "ipo"
    ]
    
    COMMODITY_KEYWORDS = [
        "gold", "silver", "oil", "crude", "brent", "natural gas", "copper",
        "commodity", "commodities", "wheat", "corn", "agriculture"
    ]
    
    MACRO_KEYWORDS = [
        "fed", "federal reserve", "interest rate", "inflation", "cpi", "gdp",
        "unemployment", "jobs report", "central bank", "boe", "ecb",
        "recession", "economy", "economic", "monetary policy"
    ]
    
    GEOPOLITICAL_KEYWORDS = [
        "war", "conflict", "sanctions", "trade war", "tariff", "election",
        "political", "geopolitical", "tension", "diplomatic", "nato", "eu"
    ]
    
    def __init__(self, news_api_key: Optional[str] = None):
        self.news_api_key = news_api_key
        self.sentiment_analyzer = SentimentIntensityAnalyzer()
        self._cache = []
        self._cache_time = None
        self._cache_duration = 300  # 5 minutes
        
    def analyze_sentiment(self, text: str) -> Dict[str, Any]:
        """Analyze sentiment of text"""
        scores = self.sentiment_analyzer.polarity_scores(text)
        compound = scores["compound"]
        
        if compound >= 0.05:
            label = "positive"
        elif compound <= -0.05:
            label = "negative"
        else:
            label = "neutral"
            
        return {
            "score": compound,
            "label": label,
            "positive": scores["pos"],
            "negative": scores["neg"],
            "neutral": scores["neu"]
        }
    
    def tag_assets(self, text: str) -> List[str]:
        """Tag assets mentioned in text"""
        text_lower = text.lower()
        tags = []
        
        for keyword in self.CRYPTO_KEYWORDS:
            if keyword in text_lower:
                tags.append("crypto")
                break
                
        for keyword in self.STOCK_KEYWORDS:
            if keyword in text_lower:
                tags.append("stocks")
                break
                
        for keyword in self.COMMODITY_KEYWORDS:
            if keyword in text_lower:
                tags.append("commodities")
                break
                
        return tags
    
    def tag_topics(self, text: str) -> List[str]:
        """Tag topics in text"""
        text_lower = text.lower()
        topics = []
        
        if any(k in text_lower for k in self.MACRO_KEYWORDS):
            topics.append("macro")
        if any(k in text_lower for k in self.GEOPOLITICAL_KEYWORDS):
            topics.append("geopolitics")
        if any(k in text_lower for k in ["etf", "bitcoin etf", "ethereum etf"]):
            topics.append("etf")
            
        return topics
    
    def calculate_impact(self, text: str, sentiment: Dict) -> float:
        """Calculate potential market impact (0-10)"""
        text_lower = text.lower()
        impact = 5.0
        
        # High impact keywords
        high_impact = ["crash", "surge", "plunge", "rally", "breakthrough", "ban", "approval", "rejection"]
        for word in high_impact:
            if word in text_lower:
                impact += 1.5
                
        # Sentiment intensity increases impact
        impact += abs(sentiment["score"]) * 2
        
        # Macro events are high impact
        if any(k in text_lower for k in ["fed", "interest rate", "recession"]):
            impact += 1
            
        return min(10, max(1, impact))
    
    async def fetch_rss_feed(self, source: str, url: str) -> List[Dict]:
        """Fetch and parse RSS feed"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, timeout=30.0, headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                })
                response.raise_for_status()
                
            feed = feedparser.parse(response.text)
            articles = []
            
            for entry in feed.entries[:20]:  # Limit to 20 per source
                title = entry.get("title", "")
                summary = entry.get("summary", entry.get("description", ""))
                text = f"{title} {summary}"
                
                sentiment = self.analyze_sentiment(text)
                
                articles.append({
                    "id": f"{source}_{hash(title)}",
                    "title": title,
                    "summary": summary[:300] if summary else None,
                    "source": source,
                    "url": entry.get("link", ""),
                    "published_at": datetime.now(),  # RSS dates can be unreliable
                    "asset_tags": self.tag_assets(text),
                    "topic_tags": self.tag_topics(text),
                    "sentiment_score": sentiment["score"],
                    "sentiment_label": sentiment["label"],
                    "impact_score": self.calculate_impact(text, sentiment),
                    "relevance_score": 0.8
                })
                
            return articles
            
        except Exception as e:
            logger.error(f"Error fetching RSS feed {source}: {e}")
            return []
    
    async def fetch_crypto_news(self) -> List[Dict]:
        """Fetch crypto-specific news"""
        tasks = []
        for source, url in self.RSS_FEEDS.items():
            if "coin" in source.lower() or "crypto" in source.lower():
                tasks.append(self.fetch_rss_feed(source, url))
                
        results = await asyncio.gather(*tasks, return_exceptions=True)
        articles = []
        for result in results:
            if isinstance(result, list):
                articles.extend(result)
        return articles
    
    async def fetch_all_news(self, limit: int = 50) -> List[Dict]:
        """Fetch all news with caching"""
        if self._cache and self._cache_time:
            if datetime.now() - self._cache_time < timedelta(seconds=self._cache_duration):
                return self._cache[:limit]
        
        tasks = []
        for source, url in self.RSS_FEEDS.items():
            tasks.append(self.fetch_rss_feed(source, url))
            
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        all_articles = []
        for result in results:
            if isinstance(result, list):
                all_articles.extend(result)
                
        # Sort by published date (newest first)
        all_articles.sort(key=lambda x: x["published_at"], reverse=True)
        
        self._cache = all_articles
        self._cache_time = datetime.now()
        
        return all_articles[:limit]
    
    async def get_news_for_asset(self, symbol: str, asset_type: str = None) -> List[Dict]:
        """Get news filtered for specific asset"""
        all_news = await self.fetch_all_news(100)
        
        symbol_lower = symbol.lower()
        filtered = []
        
        for article in all_news:
            text = f"{article['title']} {article.get('summary', '')}".lower()
            
            # Check if symbol is mentioned
            if symbol_lower in text:
                article["relevance_score"] = 1.0
                filtered.append(article)
            # Check for related keywords
            elif asset_type == "crypto" and any(k in text for k in self.CRYPTO_KEYWORDS):
                if article not in filtered:
                    article["relevance_score"] = 0.6
                    filtered.append(article)
                    
        return filtered[:20]


# Singleton instance
_news_provider = None


def get_news_provider() -> NewsProvider:
    global _news_provider
    if _news_provider is None:
        _news_provider = NewsProvider()
    return _news_provider
