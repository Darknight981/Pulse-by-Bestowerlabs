import { useState, useEffect } from 'react';
import { ArrowRightLeft, TrendingUp, TrendingDown, Activity, Wallet, Fish } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { getFlowData } from '@/lib/api';
import type { WhaleTransaction, ExchangeFlow } from '@/types';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

const CRYPTO_SYMBOLS = ['BTC', 'ETH', 'BNB', 'SOL', 'XRP', 'ADA'];

export default function WhaleMonitor() {
  const [selectedSymbol, setSelectedSymbol] = useState('BTC');
  const [transactions, setTransactions] = useState<WhaleTransaction[]>([]);
  const [exchangeFlows, setExchangeFlows] = useState<ExchangeFlow[]>([]);
  const [accumulation, setAccumulation] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const data = await getFlowData(selectedSymbol);
        setTransactions(data.transactions);
        setExchangeFlows(data.exchange_flows);
        setAccumulation(data.accumulation_trend);
      } catch (error) {
        console.error('Error fetching whale data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, [selectedSymbol]);

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'inflow':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      case 'outflow':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      default:
        return <ArrowRightLeft className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatAmount = (amount: number) => {
    if (amount >= 1e9) return `$${(amount / 1e9).toFixed(2)}B`;
    if (amount >= 1e6) return `$${(amount / 1e6).toFixed(2)}M`;
    if (amount >= 1e3) return `$${(amount / 1e3).toFixed(2)}K`;
    return `$${amount.toFixed(2)}`;
  };

  const chartData = exchangeFlows.map(flow => ({
    name: flow.exchange.charAt(0).toUpperCase() + flow.exchange.slice(1),
    inflow: flow.inflow_usd / 1e6,
    outflow: flow.outflow_usd / 1e6,
    netflow: flow.netflow_usd / 1e6
  }));

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
        <Skeleton className="h-80" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Fish className="h-6 w-6" />
          <h2 className="text-2xl font-bold">Whale Monitor</h2>
        </div>
        <Select value={selectedSymbol} onValueChange={setSelectedSymbol}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Select asset" />
          </SelectTrigger>
          <SelectContent>
            {CRYPTO_SYMBOLS.map((symbol) => (
              <SelectItem key={symbol} value={symbol}>
                {symbol}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Accumulation Trend</p>
                <p className={`text-2xl font-bold capitalize ${
                  accumulation?.trend === 'accumulation' ? 'text-green-500' :
                  accumulation?.trend === 'distribution' ? 'text-red-500' :
                  'text-yellow-500'
                }`}>
                  {accumulation?.trend || 'Neutral'}
                </p>
              </div>
              <Activity className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Net Flow</p>
                <p className={`text-2xl font-bold ${
                  (accumulation?.net_flow || 0) > 0 ? 'text-green-500' : 'text-red-500'
                }`}>
                  {formatAmount(accumulation?.net_flow || 0)}
                </p>
              </div>
              <ArrowRightLeft className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Volume</p>
                <p className="text-2xl font-bold">
                  {formatAmount(accumulation?.total_volume || 0)}
                </p>
              </div>
              <Wallet className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Exchange Flows Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Exchange Flows (USD Millions)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value: number) => `$${value.toFixed(1)}M`} />
                <Bar dataKey="inflow" fill="#ef4444" name="Inflow" />
                <Bar dataKey="outflow" fill="#22c55e" name="Outflow" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Recent Whale Transactions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Whale Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {transactions.map((tx) => (
              <div 
                key={tx.id} 
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent transition-colors"
              >
                <div className="flex items-center gap-3">
                  {getTransactionIcon(tx.transaction_type)}
                  <div>
                    <p className="font-medium capitalize">{tx.transaction_type}</p>
                    <p className="text-sm text-muted-foreground">
                      {tx.from_exchange || 'Unknown'} to {tx.to_exchange || 'Unknown'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold">{tx.amount.toLocaleString()} {tx.symbol}</p>
                  <p className="text-sm text-muted-foreground">
                    {formatAmount(tx.amount_usd)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Exchange Flow Table */}
      <Card>
        <CardHeader>
          <CardTitle>Exchange Flow Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Exchange</th>
                  <th className="text-right p-2">Inflow</th>
                  <th className="text-right p-2">Outflow</th>
                  <th className="text-right p-2">Net Flow</th>
                  <th className="text-right p-2">Signal</th>
                </tr>
              </thead>
              <tbody>
                {exchangeFlows.map((flow) => (
                  <tr key={flow.exchange} className="border-b last:border-b-0">
                    <td className="p-2 capitalize font-medium">{flow.exchange}</td>
                    <td className="text-right p-2 text-red-500">
                      {formatAmount(flow.inflow_usd)}
                    </td>
                    <td className="text-right p-2 text-green-500">
                      {formatAmount(flow.outflow_usd)}
                    </td>
                    <td className={`text-right p-2 font-bold ${
                      flow.netflow_usd > 0 ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {formatAmount(flow.netflow_usd)}
                    </td>
                    <td className="text-right p-2">
                      <Badge className={
                        flow.netflow_usd > 0 ? 'bg-green-500' : 'bg-red-500'
                      }>
                        {flow.netflow_usd > 0 ? 'Accumulation' : 'Distribution'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
