#!/bin/bash

# PULSE Backend Startup Script
# Usage: ./start.sh [dev|prod]

MODE=${1:-prod}

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}Starting PULSE Backend...${NC}"

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo -e "${YELLOW}Creating virtual environment...${NC}"
    python3 -m venv venv
fi

# Activate virtual environment
echo -e "${YELLOW}Activating virtual environment...${NC}"
source venv/bin/activate

# Install/update dependencies
echo -e "${YELLOW}Installing dependencies...${NC}"
pip install -q -r requirements.txt

# Create data directory if not exists
mkdir -p data

# Set environment variables based on mode
if [ "$MODE" = "dev" ]; then
    echo -e "${YELLOW}Starting in DEVELOPMENT mode${NC}"
    export DEBUG=true
    export PORT=8000
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
else
    echo -e "${GREEN}Starting in PRODUCTION mode${NC}"
    export DEBUG=false
    export PORT=8000
    
    # Check if .env file exists
    if [ -f ".env" ]; then
        echo -e "${YELLOW}Loading environment from .env${NC}"
        export $(grep -v '^#' .env | xargs)
    fi
    
    # Start with uvicorn (production)
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
fi
