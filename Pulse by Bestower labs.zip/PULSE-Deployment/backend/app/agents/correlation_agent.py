"""Correlation Agent - Analyzes asset correlations"""
from .base import BaseAgent
from typing import Dict, Any, List
from datetime import datetime
import numpy as np


class CorrelationAgent(BaseAgent):
    """Analyzes correlations between assets"""
    
    def __init__(self):
        super().__init__("Correlation Agent", "correlation")
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze correlations"""
        symbol = context.get("symbol", "BTC")
        asset_type = context.get("asset_type", "crypto")
        related_prices = context.get("related_prices", {})
        
        if not related_prices:
            return {
                "confidence": 50,
                "analysis": "No correlation data available.",
                "data": {"correlation_regime": "unknown"}
            }
        
        # Determine market regime
        btc_change = related_prices.get("BTC", {}).get("change_24h", 0)
        eth_change = related_prices.get("ETH", {}).get("change_24h", 0)
        spy_change = related_prices.get("SPY", {}).get("change_24h", 0)
        
        # Crypto correlation
        crypto_aligned = abs(btc_change - eth_change) < 2
        
        # Risk-on / Risk-off
        if btc_change > 2 and spy_change > 1:
            regime = "risk_on"
        elif btc_change < -2 and spy_change < -1:
            regime = "risk_off"
        elif btc_change > 2 and spy_change < -1:
            regime = "crypto_decoupling_bullish"
        elif btc_change < -2 and spy_change > 1:
            regime = "crypto_decoupling_bearish"
        else:
            regime = "mixed"
        
        # Asset-specific correlation
        if asset_type == "crypto":
            if symbol == "BTC":
                correlation = "market_leader"
                confidence = 70
            elif symbol == "ETH":
                correlation = "highly_correlated_to_btc"
                confidence = 75
            else:
                correlation = "follows_btc_with_beta"
                confidence = 65
        elif asset_type == "commodity":
            if symbol in ["GOLD", "SILVER"]:
                correlation = "safe_haven"
                confidence = 60
            elif symbol in ["OIL", "BRENT"]:
                correlation = "inflation_sensitive"
                confidence = 60
            else:
                correlation = "commodity_complex"
                confidence = 55
        else:
            correlation = "market_correlated"
            confidence = 60
        
        analysis = f"""
        Correlation Analysis for {symbol}:
        - Market Regime: {regime}
        - BTC 24h: {btc_change:+.2f}%
        - ETH 24h: {eth_change:+.2f}%
        - SPY 24h: {spy_change:+.2f}%
        - Crypto Aligned: {crypto_aligned}
        - Asset Correlation: {correlation}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "regime": regime,
                "correlation": correlation,
                "btc_change": btc_change,
                "eth_change": eth_change,
                "spy_change": spy_change,
                "crypto_aligned": crypto_aligned
            }
        }
