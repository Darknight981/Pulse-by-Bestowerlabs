"""Geopolitical Risk Agent - Analyzes geopolitical factors"""
from .base import BaseAgent
from typing import Dict, Any, List
from datetime import datetime


class GeopoliticalRiskAgent(BaseAgent):
    """Analyzes geopolitical risks affecting markets"""
    
    def __init__(self):
        super().__init__("Geopolitical Risk Agent", "geopolitical")
        
        self.risk_keywords = {
            "high": ["war", "conflict", "invasion", "sanctions", "trade war", "nuclear"],
            "medium": ["tension", "dispute", "protest", "election", "brexit", "tariff"],
            "low": ["diplomatic", "negotiation", "talks", "summit"]
        }
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze geopolitical risks"""
        symbol = context.get("symbol", "BTC")
        asset_type = context.get("asset_type", "crypto")
        news = context.get("news", [])
        
        # Scan for geopolitical events
        high_risk_events = []
        medium_risk_events = []
        
        for article in news:
            title = article.get("title", "").lower()
            
            for keyword in self.risk_keywords["high"]:
                if keyword in title:
                    high_risk_events.append(article)
                    break
            else:
                for keyword in self.risk_keywords["medium"]:
                    if keyword in title:
                        medium_risk_events.append(article)
                        break
        
        # Calculate risk level
        risk_score = 0
        if high_risk_events:
            risk_score += len(high_risk_events) * 3
        if medium_risk_events:
            risk_score += len(medium_risk_events) * 1
        
        if risk_score >= 6:
            risk_level = "high"
            market_impact = "significant_risk_off"
            confidence = 80
        elif risk_score >= 3:
            risk_level = "elevated"
            market_impact = "moderate_caution"
            confidence = 70
        elif risk_score >= 1:
            risk_level = "moderate"
            market_impact = "minor_impact"
            confidence = 60
        else:
            risk_level = "low"
            market_impact = "minimal_impact"
            confidence = 55
        
        # Asset-specific impact
        if asset_type == "commodity" and symbol in ["GOLD", "SILVER", "OIL"]:
            if risk_level in ["high", "elevated"]:
                if symbol == "GOLD":
                    asset_impact = "bullish_safe_haven"
                elif symbol in ["OIL", "BRENT"]:
                    asset_impact = "bullish_supply_risk"
                else:
                    asset_impact = "mixed"
            else:
                asset_impact = "neutral"
        elif asset_type == "crypto":
            asset_impact = "risk_off_negative" if risk_level == "high" else "neutral"
        else:
            asset_impact = "risk_off_negative" if risk_level == "high" else "neutral"
        
        analysis = f"""
        Geopolitical Risk Analysis:
        - Risk Level: {risk_level}
        - Risk Score: {risk_score}/10
        - High Risk Events: {len(high_risk_events)}
        - Medium Risk Events: {len(medium_risk_events)}
        - Market Impact: {market_impact}
        - Asset Impact: {asset_impact}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "risk_level": risk_level,
                "risk_score": risk_score,
                "high_risk_count": len(high_risk_events),
                "medium_risk_count": len(medium_risk_events),
                "market_impact": market_impact,
                "asset_impact": asset_impact,
                "key_events": [e.get("title", "") for e in high_risk_events[:3]]
            }
        }
