"""News Analysis Agent - Analyzes news impact"""
from .base import BaseAgent
from typing import Dict, Any, List
from datetime import datetime


class NewsAnalysisAgent(BaseAgent):
    """Analyzes news and events for market impact"""
    
    def __init__(self):
        super().__init__("News Analysis Agent", "news")
        
        self.bullish_keywords = [
            "approval", "adoption", "partnership", "bullish", "rally", "surge",
            "breakthrough", "upgrade", "launch", "growth", "positive", "gain"
        ]
        
        self.bearish_keywords = [
            "ban", "regulation", "hack", "crash", "bearish", "decline", "plunge",
            "lawsuit", "investigation", "negative", "loss", "sell-off", "dump"
        ]
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze news impact"""
        symbol = context.get("symbol", "BTC")
        news = context.get("news", [])
        
        if not news:
            return {
                "confidence": 50,
                "analysis": f"No recent news for {symbol}.",
                "data": {"impact": "neutral", "key_events": []}
            }
        
        # Analyze recent headlines
        bullish_count = 0
        bearish_count = 0
        key_events = []
        
        for article in news[:10]:  # Analyze top 10
            title = article.get("title", "").lower()
            
            # Count keyword matches
            b_count = sum(1 for kw in self.bullish_keywords if kw in title)
            be_count = sum(1 for kw in self.bearish_keywords if kw in title)
            
            if b_count > be_count:
                bullish_count += 1
            elif be_count > b_count:
                bearish_count += 1
            
            # Track high impact events
            if article.get("impact_score", 0) > 7:
                key_events.append({
                    "title": article["title"],
                    "impact": article.get("impact_score", 5),
                    "sentiment": article.get("sentiment_label", "neutral")
                })
        
        # Determine news impact
        total_analyzed = bullish_count + bearish_count
        if total_analyzed == 0:
            impact = "neutral"
            confidence = 50
        else:
            bullish_pct = bullish_count / total_analyzed
            
            if bullish_pct > 0.7:
                impact = "strongly_bullish"
                confidence = 80
            elif bullish_pct > 0.55:
                impact = "bullish"
                confidence = 65
            elif bullish_pct < 0.3:
                impact = "strongly_bearish"
                confidence = 80
            elif bullish_pct < 0.45:
                impact = "bearish"
                confidence = 65
            else:
                impact = "mixed"
                confidence = 55
        
        analysis = f"""
        News Analysis for {symbol}:
        - News Impact: {impact}
        - Bullish Articles: {bullish_count}
        - Bearish Articles: {bearish_count}
        - Key Events: {len(key_events)}
        - Recent Headlines Analyzed: {len(news[:10])}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "impact": impact,
                "bullish_count": bullish_count,
                "bearish_count": bearish_count,
                "key_events": key_events[:5]
            }
        }
