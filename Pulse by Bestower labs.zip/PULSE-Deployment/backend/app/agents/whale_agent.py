"""Whale Activity Agent - Analyzes large holder movements"""
from .base import BaseAgent
from typing import Dict, Any
from datetime import datetime


class WhaleActivityAgent(BaseAgent):
    """Analyzes whale and large holder activity"""
    
    def __init__(self):
        super().__init__("Whale Activity Agent", "whale")
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze whale activity"""
        symbol = context.get("symbol", "BTC")
        whale_data = context.get("whale_data", {})
        
        transactions = whale_data.get("transactions", [])
        accumulation = whale_data.get("accumulation", {})
        
        if not transactions and not accumulation:
            return {
                "confidence": 50,
                "analysis": f"No whale data available for {symbol}.",
                "data": {"signal": "neutral", "activity_level": "low"}
            }
        
        # Analyze transaction patterns
        inflows = [t for t in transactions if t.get("transaction_type") == "inflow"]
        outflows = [t for t in transactions if t.get("transaction_type") == "outflow"]
        
        total_inflow = sum(t.get("amount_usd", 0) for t in inflows)
        total_outflow = sum(t.get("amount_usd", 0) for t in outflows)
        
        # Determine activity level
        total_volume = total_inflow + total_outflow
        if total_volume > 500000000:  # $500M
            activity_level = "very_high"
        elif total_volume > 100000000:  # $100M
            activity_level = "high"
        elif total_volume > 10000000:  # $10M
            activity_level = "moderate"
        else:
            activity_level = "low"
        
        # Determine signal
        trend = accumulation.get("trend", "neutral")
        
        if trend == "accumulation":
            signal = "bullish"
            confidence = 75
            reasoning = "Large holders accumulating (outflow from exchanges)"
        elif trend == "distribution":
            signal = "bearish"
            confidence = 75
            reasoning = "Large holders distributing (inflow to exchanges)"
        else:
            signal = "neutral"
            confidence = 50
            reasoning = "No clear accumulation or distribution pattern"
        
        # Exchange breakdown
        exchange_flows = accumulation.get("exchange_breakdown", [])
        net_flow = sum(f.get("netflow", 0) for f in exchange_flows)
        
        analysis = f"""
        Whale Activity Analysis for {symbol}:
        - Activity Level: {activity_level}
        - Total Volume: ${total_volume:,.0f}
        - Inflows (to exchanges): ${total_inflow:,.0f}
        - Outflows (from exchanges): ${total_outflow:,.0f}
        - Net Flow: ${net_flow:,.0f}
        - Trend: {trend}
        - Signal: {signal}
        - Reasoning: {reasoning}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "signal": signal,
                "activity_level": activity_level,
                "trend": trend,
                "total_volume": total_volume,
                "inflow": total_inflow,
                "outflow": total_outflow,
                "net_flow": net_flow,
                "transaction_count": len(transactions)
            }
        }
