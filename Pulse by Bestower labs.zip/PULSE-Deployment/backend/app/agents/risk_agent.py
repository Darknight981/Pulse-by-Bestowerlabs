"""Risk Management Agent - Analyzes risk factors"""
from .base import BaseAgent
from typing import Dict, Any
from datetime import datetime


class RiskManagementAgent(BaseAgent):
    """Analyzes risk factors and position sizing"""
    
    def __init__(self):
        super().__init__("Risk Management Agent", "risk")
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze risk"""
        symbol = context.get("symbol", "BTC")
        asset_type = context.get("asset_type", "crypto")
        market_data = context.get("market_data", {})
        technicals = context.get("technicals", {})
        
        # Volatility assessment
        change_24h = abs(market_data.get("change_percent_24h", 0))
        
        if change_24h > 10:
            volatility = "extreme"
            vol_score = 10
        elif change_24h > 5:
            volatility = "high"
            vol_score = 7
        elif change_24h > 2:
            volatility = "moderate"
            vol_score = 5
        else:
            volatility = "low"
            vol_score = 3
        
        # Asset class risk
        if asset_type == "crypto":
            base_risk = 8
        elif asset_type == "commodity":
            base_risk = 6
        else:
            base_risk = 5
        
        # Trend risk
        trend = technicals.get("trend", "neutral")
        if "strong" in trend:
            trend_risk = 3  # Clear direction = lower uncertainty
        elif trend == "neutral":
            trend_risk = 7  # Uncertain direction
        else:
            trend_risk = 5
        
        # Overall risk score (0-10)
        risk_score = min(10, (vol_score + base_risk + trend_risk) / 3)
        
        # Position sizing recommendation
        if risk_score > 8:
            position_size = "minimal"
            max_risk_pct = 1
        elif risk_score > 6:
            position_size = "small"
            max_risk_pct = 2
        elif risk_score > 4:
            position_size = "moderate"
            max_risk_pct = 3
        else:
            position_size = "normal"
            max_risk_pct = 5
        
        # Risk level
        if risk_score >= 8:
            risk_level = "very_high"
        elif risk_score >= 6:
            risk_level = "high"
        elif risk_score >= 4:
            risk_level = "moderate"
        else:
            risk_level = "low"
        
        analysis = f"""
        Risk Analysis for {symbol}:
        - Risk Score: {risk_score:.1f}/10
        - Risk Level: {risk_level}
        - Volatility: {volatility} ({change_24h:.2f}%)
        - Base Asset Risk: {base_risk}/10
        - Trend Risk: {trend_risk}/10
        - Recommended Position: {position_size}
        - Max Risk per Trade: {max_risk_pct}%
        """
        
        return {
            "confidence": 70,
            "analysis": analysis,
            "data": {
                "risk_score": risk_score,
                "risk_level": risk_level,
                "volatility": volatility,
                "volatility_24h": change_24h,
                "position_size": position_size,
                "max_risk_pct": max_risk_pct
            }
        }
