@echo off
REM PULSE Backend Startup Script for Windows
REM Usage: start.bat [dev|prod]

set MODE=%1
if "%MODE%"=="" set MODE=prod

echo Starting PULSE Backend...

REM Check if virtual environment exists
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
)

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate.bat

REM Install/update dependencies
echo Installing dependencies...
pip install -q -r requirements.txt

REM Create data directory if not exists
if not exist "data" mkdir data

REM Set environment variables based on mode
if "%MODE%"=="dev" (
    echo Starting in DEVELOPMENT mode
    set DEBUG=true
    set PORT=8000
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
) else (
    echo Starting in PRODUCTION mode
    set DEBUG=false
    set PORT=8000
    
    REM Check if .env file exists
    if exist ".env" (
        echo Loading environment from .env
        for /f "tokens=*" %%a in (.env) do set "%%a"
    )
    
    REM Start with uvicorn (production)
    uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 2
)
