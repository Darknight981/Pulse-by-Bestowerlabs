import { useState, useEffect, useRef } from 'react';
import { Search, Activity } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { searchAssets } from '@/lib/api';
import type { SearchResult } from '@/types';

interface HeaderProps {
  onAssetSelect: (asset: SearchResult) => void;
}

export default function Header({ onAssetSelect }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [systemStatus] = useState<'online' | 'degraded' | 'offline'>('online');
  const searchRef = useRef<HTMLDivElement>(null);

  // Handle search
  useEffect(() => {
    const delayDebounce = setTimeout(async () => {
      if (searchQuery.length >= 2) {
        setIsSearching(true);
        try {
          const results = await searchAssets(searchQuery);
          setSearchResults(results);
          setShowResults(true);
        } catch (error) {
          console.error('Search error:', error);
        } finally {
          setIsSearching(false);
        }
      } else {
        setSearchResults([]);
        setShowResults(false);
      }
    }, 300);

    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  // Close search results when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (asset: SearchResult) => {
    onAssetSelect(asset);
    setSearchQuery('');
    setShowResults(false);
  };

  const getAssetTypeColor = (type: string) => {
    switch (type) {
      case 'crypto':
        return 'bg-orange-500';
      case 'us_stock':
        return 'bg-blue-500';
      case 'uk_stock':
        return 'bg-purple-500';
      case 'commodity':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <header className="border-b bg-card">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <Activity className="h-6 w-6 text-primary" />
            <div>
              <h1 className="text-xl font-bold tracking-tight">PULSE</h1>
              <p className="text-xs text-muted-foreground">by Bestower Labs</p>
            </div>
          </div>

          {/* Search */}
          <div className="flex-1 max-w-xl relative" ref={searchRef}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search assets (BTC, AAPL, GOLD...)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4"
              />
              {isSearching && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full" />
                </div>
              )}
            </div>

            {/* Search Results Dropdown */}
            {showResults && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-popover border rounded-md shadow-lg z-50 max-h-80 overflow-auto">
                {searchResults.map((result) => (
                  <button
                    key={`${result.symbol}-${result.asset_type}`}
                    onClick={() => handleSelect(result)}
                    className="w-full px-4 py-3 text-left hover:bg-accent flex items-center justify-between border-b last:border-b-0"
                  >
                    <div>
                      <div className="font-semibold">{result.symbol}</div>
                      <div className="text-sm text-muted-foreground">{result.name}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className={`${getAssetTypeColor(result.asset_type)} text-white`}>
                        {result.asset_type.replace('_', ' ')}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{result.exchange}</span>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {showResults && searchQuery.length >= 2 && searchResults.length === 0 && !isSearching && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-popover border rounded-md shadow-lg z-50 p-4 text-center text-muted-foreground">
                No assets found
              </div>
            )}
          </div>

          {/* Status */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className={`h-2 w-2 rounded-full ${
                systemStatus === 'online' ? 'bg-green-500' : 
                systemStatus === 'degraded' ? 'bg-yellow-500' : 'bg-red-500'
              }`} />
              <span className="text-sm text-muted-foreground hidden sm:inline">
                {systemStatus === 'online' ? 'System Online' : 
                 systemStatus === 'degraded' ? 'Degraded' : 'Offline'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
