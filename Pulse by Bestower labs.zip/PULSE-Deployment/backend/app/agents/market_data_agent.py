"""Market Data Agent - Analyzes current market conditions"""
from .base import BaseAgent
from typing import Dict, Any
from datetime import datetime


class MarketDataAgent(BaseAgent):
    """Analyzes current market data and price action"""
    
    def __init__(self):
        super().__init__("Market Data Agent", "market")
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze market data"""
        symbol = context.get("symbol", "BTC")
        asset_type = context.get("asset_type", "crypto")
        market_data = context.get("market_data", {})
        
        price = market_data.get("price", 0)
        change_24h = market_data.get("change_percent_24h", 0)
        volume = market_data.get("volume_24h", 0)
        
        # Analyze price action
        if change_24h > 5:
            trend = "strongly_bullish"
            confidence = 75
        elif change_24h > 2:
            trend = "bullish"
            confidence = 65
        elif change_24h < -5:
            trend = "strongly_bearish"
            confidence = 75
        elif change_24h < -2:
            trend = "bearish"
            confidence = 65
        else:
            trend = "neutral"
            confidence = 50
        
        # Volume analysis
        volume_signal = "normal"
        if volume > market_data.get("avg_volume", volume) * 1.5:
            volume_signal = "high"
            confidence += 5
        
        analysis = f"""
        Market Data Analysis for {symbol}:
        - Current Price: ${price:,.2f}
        - 24h Change: {change_24h:+.2f}%
        - 24h Volume: ${volume:,.0f}
        - Price Trend: {trend}
        - Volume Signal: {volume_signal}
        """
        
        return {
            "confidence": min(95, confidence),
            "analysis": analysis,
            "data": {
                "price": price,
                "change_24h": change_24h,
                "volume": volume,
                "trend": trend,
                "volume_signal": volume_signal
            }
        }
