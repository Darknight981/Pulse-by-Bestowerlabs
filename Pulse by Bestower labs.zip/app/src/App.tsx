import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Toaster } from '@/components/ui/sonner';
import Dashboard from './sections/Dashboard';
import AssetDetail from './sections/AssetDetail';
import NewsPanel from './sections/NewsPanel';
import WhaleMonitor from './sections/WhaleMonitor';
import AgentConsole from './sections/AgentConsole';
import Header from './sections/Header';
import type { SearchResult } from './types';
import './App.css';

function App() {
  const [selectedAsset, setSelectedAsset] = useState<SearchResult | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  // Handle asset selection
  const handleAssetSelect = (asset: SearchResult) => {
    setSelectedAsset(asset);
    setActiveTab('asset');
  };

  // Handle back to dashboard
  const handleBack = () => {
    setSelectedAsset(null);
    setActiveTab('dashboard');
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-mono">
      <Toaster />
      
      <Header onAssetSelect={handleAssetSelect} />
      
      <main className="container mx-auto p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-4">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="asset" disabled={!selectedAsset}>
              Asset Detail
            </TabsTrigger>
            <TabsTrigger value="news">News Intelligence</TabsTrigger>
            <TabsTrigger value="whale">Whale Monitor</TabsTrigger>
            <TabsTrigger value="agents">AI Agents</TabsTrigger>
          </TabsList>
          
          <TabsContent value="dashboard" className="space-y-4">
            <Dashboard onAssetSelect={handleAssetSelect} />
          </TabsContent>
          
          <TabsContent value="asset" className="space-y-4">
            {selectedAsset && (
              <AssetDetail 
                asset={selectedAsset} 
                onBack={handleBack}
              />
            )}
          </TabsContent>
          
          <TabsContent value="news" className="space-y-4">
            <NewsPanel />
          </TabsContent>
          
          <TabsContent value="whale" className="space-y-4">
            <WhaleMonitor />
          </TabsContent>
          
          <TabsContent value="agents" className="space-y-4">
            <AgentConsole />
          </TabsContent>
        </Tabs>
      </main>
      
      <footer className="border-t mt-8 py-4 text-center text-sm text-muted-foreground">
        <p>PULSE by Bestower Labs - Geo-AI Trading Terminal v1.0</p>
        <p className="text-xs mt-1">Real-time market intelligence powered by AI</p>
      </footer>
    </div>
  );
}

export default App;
