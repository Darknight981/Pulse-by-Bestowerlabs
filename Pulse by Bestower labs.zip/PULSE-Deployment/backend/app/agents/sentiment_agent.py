"""Sentiment Analysis Agent - Analyzes market sentiment"""
from .base import BaseAgent
from typing import Dict, Any
from datetime import datetime


class SentimentAnalysisAgent(BaseAgent):
    """Analyzes market sentiment from news and social data"""
    
    def __init__(self):
        super().__init__("Sentiment Analysis Agent", "sentiment")
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze sentiment"""
        symbol = context.get("symbol", "BTC")
        news = context.get("news", [])
        
        if not news:
            return {
                "confidence": 50,
                "analysis": f"No recent news for {symbol}. Sentiment neutral.",
                "data": {"sentiment": "neutral", "score": 0}
            }
        
        # Calculate average sentiment
        sentiment_scores = [n.get("sentiment_score", 0) for n in news]
        avg_sentiment = sum(sentiment_scores) / len(sentiment_scores)
        
        # Count sentiment types
        positive = sum(1 for s in sentiment_scores if s > 0.1)
        negative = sum(1 for s in sentiment_scores if s < -0.1)
        neutral = len(sentiment_scores) - positive - negative
        
        # Determine overall sentiment
        if avg_sentiment > 0.2:
            sentiment = "very_positive"
            confidence = 80
        elif avg_sentiment > 0.05:
            sentiment = "positive"
            confidence = 65
        elif avg_sentiment < -0.2:
            sentiment = "very_negative"
            confidence = 80
        elif avg_sentiment < -0.05:
            sentiment = "negative"
            confidence = 65
        else:
            sentiment = "neutral"
            confidence = 50
        
        # High impact news boost
        high_impact = sum(1 for n in news if n.get("impact_score", 5) > 7)
        if high_impact > 0:
            confidence = min(95, confidence + 5)
        
        analysis = f"""
        Sentiment Analysis for {symbol}:
        - Overall Sentiment: {sentiment}
        - Sentiment Score: {avg_sentiment:+.2f}
        - Positive Articles: {positive}
        - Negative Articles: {negative}
        - Neutral Articles: {neutral}
        - High Impact News: {high_impact}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "sentiment": sentiment,
                "score": avg_sentiment,
                "positive": positive,
                "negative": negative,
                "neutral": neutral,
                "high_impact": high_impact
            }
        }
