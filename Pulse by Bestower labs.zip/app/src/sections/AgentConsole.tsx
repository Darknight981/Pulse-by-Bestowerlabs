import { useState, useEffect } from 'react';
import { Bot, CheckCircle, XCircle, Clock, Activity, Terminal } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { getAgentStatus } from '@/lib/api';
import type { AgentOutput } from '@/types';

const AGENT_TYPES: Record<string, { name: string; description: string }> = {
  market: { name: 'Market Data Agent', description: 'Analyzes current market conditions and price action' },
  technical: { name: 'Technical Analysis Agent', description: 'Analyzes technical indicators and chart patterns' },
  sentiment: { name: 'Sentiment Analysis Agent', description: 'Analyzes market sentiment from news and social data' },
  news: { name: 'News Analysis Agent', description: 'Analyzes news and events for market impact' },
  macro: { name: 'Macro Economic Agent', description: 'Analyzes macroeconomic factors affecting markets' },
  geopolitical: { name: 'Geopolitical Risk Agent', description: 'Analyzes geopolitical risks affecting markets' },
  whale: { name: 'Whale Activity Agent', description: 'Analyzes whale and large holder activity' },
  volume: { name: 'Volume & Liquidity Agent', description: 'Analyzes volume and liquidity patterns' },
  correlation: { name: 'Correlation Agent', description: 'Analyzes correlations between assets' },
  risk: { name: 'Risk Management Agent', description: 'Analyzes risk factors and position sizing' },
  aggregator: { name: 'Signal Aggregator', description: 'Combines all agent signals into final recommendation' }
};

export default function AgentConsole() {
  const [agents, setAgents] = useState<AgentOutput[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        setLoading(true);
        const data = await getAgentStatus();
        setAgents(data.agents);
      } catch (error) {
        console.error('Error fetching agent status:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 10000); // Refresh every 10s
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Simulate agent activity logs
    const addLog = () => {
      const logMessages = [
        'Market Data Agent: Fetching price data...',
        'Technical Agent: Calculating RSI...',
        'Sentiment Agent: Analyzing news sentiment...',
        'News Agent: Processing headlines...',
        'Whale Agent: Monitoring exchange flows...',
        'Risk Agent: Calculating position size...',
        'Aggregator: Combining signals...',
      ];
      const randomLog = logMessages[Math.floor(Math.random() * logMessages.length)];
      setLogs(prev => [...prev.slice(-20), `[${new Date().toLocaleTimeString()}] ${randomLog}`]);
    };

    const interval = setInterval(addLog, 5000);
    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'running':
        return <Activity className="h-5 w-5 text-yellow-500 animate-pulse" />;
      default:
        return <Clock className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500';
      case 'error':
        return 'bg-red-500';
      case 'running':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="h-6 w-6" />
          <h2 className="text-2xl font-bold">AI Agent Console</h2>
        </div>
        <Badge variant="outline">{agents.length} Agents Active</Badge>
      </div>

      {/* Agent Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {agents.map((agent) => (
          <Card 
            key={agent.agent_name}
            className={`cursor-pointer transition-all hover:shadow-lg ${
              selectedAgent === agent.agent_name ? 'ring-2 ring-primary' : ''
            }`}
            onClick={() => setSelectedAgent(agent.agent_name)}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  {getStatusIcon(agent.status)}
                  <div>
                    <p className="font-semibold">{agent.agent_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {AGENT_TYPES[agent.agent_type]?.description || agent.agent_type}
                    </p>
                  </div>
                </div>
                <Badge className={getStatusColor(agent.status)}>
                  {agent.status}
                </Badge>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <div>
                  <p className="text-xs text-muted-foreground">Confidence</p>
                  <p className="font-mono">{agent.confidence}%</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Exec Time</p>
                  <p className="font-mono">{agent.execution_time_ms}ms</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Agent Details */}
      {selectedAgent && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Agent Details: {selectedAgent}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const agent = agents.find(a => a.agent_name === selectedAgent);
              if (!agent) return null;
              
              return (
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium">Analysis Output</p>
                    <pre className="mt-2 p-4 bg-muted rounded-lg text-sm overflow-auto max-h-64">
                      {agent.analysis}
                    </pre>
                  </div>

                  {agent.data && Object.keys(agent.data).length > 0 && (
                    <div>
                      <p className="text-sm font-medium">Data Output</p>
                      <pre className="mt-2 p-4 bg-muted rounded-lg text-sm overflow-auto max-h-64">
                        {JSON.stringify(agent.data, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              );
            })()}
          </CardContent>
        </Card>
      )}

      {/* Activity Log */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Terminal className="h-5 w-5" />
            Activity Log
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-48">
            <div className="space-y-1 font-mono text-sm">
              {logs.map((log, i) => (
                <div key={i} className="text-muted-foreground">
                  {log}
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
