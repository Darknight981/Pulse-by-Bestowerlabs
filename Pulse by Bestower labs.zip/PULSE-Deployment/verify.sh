#!/bin/bash

# PULSE Deployment Verification Script
# This script verifies that the PULSE system is deployed correctly

echo "==================================="
echo "PULSE Deployment Verification"
echo "==================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Configuration
BACKEND_URL=${1:-"http://localhost:8000"}
FRONTEND_URL=${2:-"http://localhost"}

PASSED=0
FAILED=0

# Function to test endpoint
test_endpoint() {
    local name=$1
    local url=$2
    local expected_status=${3:-200}
    
    echo -n "Testing $name... "
    
    response=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null)
    
    if [ "$response" = "$expected_status" ]; then
        echo -e "${GREEN}PASS${NC} (HTTP $response)"
        ((PASSED++))
    else
        echo -e "${RED}FAIL${NC} (Expected $expected_status, got $response)"
        ((FAILED++))
    fi
}

echo "Backend URL: $BACKEND_URL"
echo "Frontend URL: $FRONTEND_URL"
echo ""

# Test Backend Endpoints
echo "--- Backend API Tests ---"
test_endpoint "Health Check" "$BACKEND_URL/api/system/health"
test_endpoint "Asset Search" "$BACKEND_URL/api/assets/search?query=BTC"
test_endpoint "BTC Overview" "$BACKEND_URL/api/assets/BTC/overview"
test_endpoint "BTC Chart" "$BACKEND_URL/api/assets/BTC/chart"
test_endpoint "BTC Technicals" "$BACKEND_URL/api/assets/BTC/technicals"
test_endpoint "BTC News" "$BACKEND_URL/api/assets/BTC/news"
test_endpoint "BTC Flow" "$BACKEND_URL/api/assets/BTC/flow"
test_endpoint "BTC Signal" "$BACKEND_URL/api/assets/BTC/signal"
test_endpoint "Global News" "$BACKEND_URL/api/global/news"
test_endpoint "Agent Status" "$BACKEND_URL/api/agents"
test_endpoint "Dashboard" "$BACKEND_URL/api/dashboard"

echo ""
echo "--- Frontend Tests ---"
test_endpoint "Frontend Root" "$FRONTEND_URL"

echo ""
echo "--- Summary ---"
echo -e "Passed: ${GREEN}$PASSED${NC}"
echo -e "Failed: ${RED}$FAILED${NC}"
echo ""

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}All tests passed! Deployment is working correctly.${NC}"
    exit 0
else
    echo -e "${RED}Some tests failed. Please check the errors above.${NC}"
    exit 1
fi
