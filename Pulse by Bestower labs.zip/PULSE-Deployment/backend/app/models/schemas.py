"""PULSE Data Models and Schemas"""
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any, Literal
from datetime import datetime
from enum import Enum


class AssetType(str, Enum):
    CRYPTO = "crypto"
    US_STOCK = "us_stock"
    UK_STOCK = "uk_stock"
    COMMODITY = "commodity"
    FOREX = "forex"
    INDEX = "index"


class SignalType(str, Enum):
    BUY = "buy"
    SELL = "sell"
    HOLD = "hold"
    STRONG_BUY = "strong_buy"
    STRONG_SELL = "strong_sell"


class TimeFrame(str, Enum):
    M1 = "1m"
    M5 = "5m"
    M15 = "15m"
    M30 = "30m"
    H1 = "1h"
    H4 = "4h"
    D1 = "1d"
    W1 = "1w"
    M1_MONTH = "1M"


class MarketData(BaseModel):
    """Real-time market data"""
    symbol: str
    asset_type: AssetType
    price: float
    change_24h: float
    change_percent_24h: float
    volume_24h: float
    market_cap: Optional[float] = None
    high_24h: float
    low_24h: float
    bid: Optional[float] = None
    ask: Optional[float] = None
    timestamp: datetime
    source: str


class OHLCV(BaseModel):
    """OHLCV candlestick data"""
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float


class TechnicalIndicator(BaseModel):
    """Technical indicator value"""
    name: str
    value: float
    signal: Optional[str] = None
    timeframe: TimeFrame
    timestamp: datetime


class TechnicalAnalysis(BaseModel):
    """Complete technical analysis for an asset"""
    symbol: str
    timeframe: TimeFrame
    indicators: Dict[str, float]
    signals: Dict[str, str]
    trend: str
    support_levels: List[float]
    resistance_levels: List[float]
    rsi: Optional[float] = None
    macd: Optional[Dict[str, float]] = None
    bollinger_bands: Optional[Dict[str, float]] = None
    moving_averages: Optional[Dict[str, float]] = None
    timestamp: datetime


class NewsItem(BaseModel):
    """News article with sentiment"""
    id: str
    title: str
    summary: Optional[str] = None
    source: str
    url: Optional[str] = None
    published_at: datetime
    asset_tags: List[str] = []
    topic_tags: List[str] = []
    sentiment_score: float = Field(ge=-1, le=1)
    sentiment_label: Literal["positive", "negative", "neutral"]
    impact_score: float = Field(ge=0, le=10)
    relevance_score: float = Field(ge=0, le=1)


class MacroEvent(BaseModel):
    """Macroeconomic event"""
    id: str
    title: str
    description: Optional[str] = None
    country: str
    event_type: str
    impact_level: Literal["high", "medium", "low"]
    previous_value: Optional[float] = None
    forecast_value: Optional[float] = None
    actual_value: Optional[float] = None
    timestamp: datetime
    affected_assets: List[str] = []


class WhaleTransaction(BaseModel):
    """Large crypto transaction"""
    id: str
    symbol: str
    amount: float
    amount_usd: float
    from_address: Optional[str] = None
    to_address: Optional[str] = None
    from_exchange: Optional[str] = None
    to_exchange: Optional[str] = None
    transaction_type: Literal["inflow", "outflow", "transfer"]
    timestamp: datetime
    blockchain: str


class ExchangeFlow(BaseModel):
    """Exchange flow data"""
    exchange: str
    symbol: str
    inflow: float
    outflow: float
    netflow: float
    inflow_usd: float
    outflow_usd: float
    netflow_usd: float
    timestamp: datetime


class AgentOutput(BaseModel):
    """Individual agent analysis output"""
    agent_name: str
    agent_type: str
    status: Literal["running", "completed", "error"]
    confidence: float = Field(ge=0, le=100)
    analysis: str
    data: Dict[str, Any]
    timestamp: datetime
    execution_time_ms: int


class TradeSignal(BaseModel):
    """Final trade signal"""
    symbol: str
    asset_type: AssetType
    signal: SignalType
    confidence: float = Field(ge=0, le=100)
    risk_score: float = Field(ge=0, le=10)
    timeframe: TimeFrame
    entry_zone: Dict[str, float]
    stop_loss: float
    take_profit: List[float]
    supporting_evidence: List[str]
    opposing_risks: List[str]
    thesis: str
    rationale: str
    agents_contributed: List[str]
    timestamp: datetime
    valid_until: datetime


class MarketSentiment(BaseModel):
    """Overall market sentiment"""
    overall_score: float = Field(ge=0, le=100)
    label: Literal["extreme_fear", "fear", "neutral", "greed", "extreme_greed"]
    crypto_score: float = Field(ge=0, le=100)
    equities_score: float = Field(ge=0, le=100)
    commodities_score: float = Field(ge=0, le=100)
    fear_greed_index: int = Field(ge=0, le=100)
    timestamp: datetime


class GeopoliticalRisk(BaseModel):
    """Geopolitical risk assessment"""
    overall_risk: float = Field(ge=0, le=10)
    risk_level: Literal["low", "moderate", "elevated", "high", "severe"]
    active_events: List[Dict[str, Any]]
    affected_regions: List[str]
    market_impact: str
    timestamp: datetime


class AssetOverview(BaseModel):
    """Complete asset overview"""
    symbol: str
    name: str
    asset_type: AssetType
    market_data: MarketData
    technical_analysis: Optional[TechnicalAnalysis] = None
    news: List[NewsItem] = []
    signals: List[TradeSignal] = []
    related_assets: List[str] = []
    timestamp: datetime


class DashboardData(BaseModel):
    """Complete dashboard data"""
    timestamp: datetime
    market_sentiment: MarketSentiment
    top_movers: List[MarketData]
    trending_assets: List[str]
    latest_news: List[NewsItem]
    active_signals: List[TradeSignal]
    macro_events: List[MacroEvent]
    whale_activity: List[WhaleTransaction]
    geopolitical_risk: GeopoliticalRisk
    agent_status: Dict[str, str]


class SystemHealth(BaseModel):
    """System health status"""
    status: Literal["healthy", "degraded", "unhealthy"]
    uptime_seconds: int
    version: str
    services: Dict[str, Dict[str, Any]]
    last_update: datetime
