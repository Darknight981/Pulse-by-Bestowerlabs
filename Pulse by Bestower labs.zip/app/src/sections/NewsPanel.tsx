import { useState, useEffect } from 'react';
import { Newspaper, TrendingUp, TrendingDown, Minus, AlertCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { getGlobalNews } from '@/lib/api';
import type { NewsItem } from '@/types';

export default function NewsPanel() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [filteredNews, setFilteredNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'positive' | 'negative' | 'high_impact'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchNews = async () => {
      try {
        setLoading(true);
        const data = await getGlobalNews(100);
        setNews(data);
        setFilteredNews(data);
      } catch (error) {
        console.error('Error fetching news:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
    const interval = setInterval(fetchNews, 300000); // Refresh every 5 minutes
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let filtered = news;

    // Apply sentiment filter
    if (filter === 'positive') {
      filtered = filtered.filter(n => n.sentiment_label === 'positive');
    } else if (filter === 'negative') {
      filtered = filtered.filter(n => n.sentiment_label === 'negative');
    } else if (filter === 'high_impact') {
      filtered = filtered.filter(n => n.impact_score > 7);
    }

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(n => 
        n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.source.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredNews(filtered);
  }, [filter, searchQuery, news]);

  const getSentimentIcon = (label: string) => {
    switch (label) {
      case 'positive':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'negative':
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      default:
        return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  const getImpactColor = (score: number) => {
    if (score >= 8) return 'bg-red-500';
    if (score >= 6) return 'bg-orange-500';
    if (score >= 4) return 'bg-yellow-500';
    return 'bg-gray-500';
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        {[...Array(5)].map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Newspaper className="h-6 w-6" />
          <h2 className="text-2xl font-bold">News Intelligence</h2>
        </div>
        <Badge variant="outline">{filteredNews.length} articles</Badge>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search news..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('all')}
              >
                All
              </Button>
              <Button
                variant={filter === 'positive' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('positive')}
                className="text-green-500"
              >
                <TrendingUp className="h-4 w-4 mr-1" />
                Positive
              </Button>
              <Button
                variant={filter === 'negative' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('negative')}
                className="text-red-500"
              >
                <TrendingDown className="h-4 w-4 mr-1" />
                Negative
              </Button>
              <Button
                variant={filter === 'high_impact' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter('high_impact')}
              >
                <AlertCircle className="h-4 w-4 mr-1" />
                High Impact
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* News Grid */}
      <div className="grid gap-4">
        {filteredNews.map((item) => (
          <Card key={item.id} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{item.title}</h3>
                  {item.summary && (
                    <p className="text-muted-foreground mt-1">{item.summary}</p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 mt-3">
                <Badge variant="outline">{item.source}</Badge>
                
                <Badge className={
                  item.sentiment_label === 'positive' ? 'bg-green-500' :
                  item.sentiment_label === 'negative' ? 'bg-red-500' :
                  'bg-gray-500'
                }>
                  {getSentimentIcon(item.sentiment_label)}
                  <span className="ml-1 capitalize">{item.sentiment_label}</span>
                </Badge>

                <Badge className={getImpactColor(item.impact_score)}>
                  Impact: {item.impact_score}/10
                </Badge>

                {item.asset_tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}

                {item.topic_tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>

              {item.url && (
                <div className="mt-3">
                  <a 
                    href={item.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-sm text-primary hover:underline"
                  >
                    Read more
                  </a>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredNews.length === 0 && (
        <div className="text-center py-12">
          <Newspaper className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-lg font-semibold">No news found</p>
          <p className="text-muted-foreground">Try adjusting your filters</p>
        </div>
      )}
    </div>
  );
}
