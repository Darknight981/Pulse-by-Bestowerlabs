"""Volume & Liquidity Agent - Analyzes volume patterns"""
from .base import BaseAgent
from typing import Dict, Any, List
from datetime import datetime


class VolumeLiquidityAgent(BaseAgent):
    """Analyzes volume and liquidity patterns"""
    
    def __init__(self):
        super().__init__("Volume & Liquidity Agent", "volume")
    
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze volume patterns"""
        symbol = context.get("symbol", "BTC")
        ohlcv = context.get("ohlcv", [])
        
        if not ohlcv or len(ohlcv) < 20:
            return {
                "confidence": 50,
                "analysis": f"Insufficient volume data for {symbol}.",
                "data": {"signal": "neutral", "liquidity": "normal"}
            }
        
        volumes = [c.get("volume", 0) for c in ohlcv]
        closes = [c.get("close", 0) for c in ohlcv]
        
        # Calculate volume metrics
        avg_volume = sum(volumes[:-5]) / len(volumes[:-5]) if len(volumes) > 5 else sum(volumes) / len(volumes)
        current_volume = volumes[-1]
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
        
        # Volume trend
        recent_volumes = volumes[-5:]
        volume_trend = "increasing" if recent_volumes[-1] > recent_volumes[0] else "decreasing"
        
        # Price-volume relationship
        price_change = ((closes[-1] - closes[-5]) / closes[-5] * 100) if len(closes) >= 5 and closes[-5] > 0 else 0
        
        # Volume signal
        if volume_ratio > 2 and price_change > 2:
            signal = "strong_bullish_confirmd"
            confidence = 80
        elif volume_ratio > 2 and price_change < -2:
            signal = "strong_bearish_confirmed"
            confidence = 80
        elif volume_ratio > 1.5 and price_change > 0:
            signal = "bullish_volume"
            confidence = 65
        elif volume_ratio > 1.5 and price_change < 0:
            signal = "bearish_volume"
            confidence = 65
        elif volume_ratio < 0.5:
            signal = "low_volume_caution"
            confidence = 55
        else:
            signal = "normal_volume"
            confidence = 50
        
        # Liquidity assessment
        if current_volume > avg_volume * 2:
            liquidity = "high"
        elif current_volume < avg_volume * 0.5:
            liquidity = "low"
        else:
            liquidity = "normal"
        
        analysis = f"""
        Volume & Liquidity Analysis for {symbol}:
        - Current Volume: {current_volume:,.0f}
        - Average Volume: {avg_volume:,.0f}
        - Volume Ratio: {volume_ratio:.2f}x
        - Volume Trend: {volume_trend}
        - Price Change (5d): {price_change:+.2f}%
        - Signal: {signal}
        - Liquidity: {liquidity}
        """
        
        return {
            "confidence": confidence,
            "analysis": analysis,
            "data": {
                "signal": signal,
                "volume_ratio": volume_ratio,
                "volume_trend": volume_trend,
                "current_volume": current_volume,
                "avg_volume": avg_volume,
                "liquidity": liquidity,
                "price_change_5d": price_change
            }
        }
