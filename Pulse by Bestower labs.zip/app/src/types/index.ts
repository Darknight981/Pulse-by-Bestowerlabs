export interface SearchResult {
  symbol: string;
  name: string;
  asset_type: string;
  exchange: string;
}

export interface MarketData {
  symbol: string;
  asset_type: string;
  price: number;
  change_24h: number;
  change_percent_24h: number;
  volume_24h: number;
  market_cap?: number;
  high_24h: number;
  low_24h: number;
  bid?: number;
  ask?: number;
  timestamp: string;
}

export interface OHLCV {
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface TechnicalIndicator {
  name: string;
  value: number;
  signal?: string;
  timeframe: string;
  timestamp: string;
}

export interface TechnicalAnalysis {
  symbol: string;
  timeframe: string;
  indicators: Record<string, number>;
  signals: string[];
  trend: string;
  support_levels: number[];
  resistance_levels: number[];
  rsi?: number;
  macd?: Record<string, number>;
  bollinger_bands?: Record<string, number>;
  moving_averages?: Record<string, number>;
  timestamp: string;
}

export interface NewsItem {
  id: string;
  title: string;
  summary?: string;
  source: string;
  url?: string;
  published_at: string;
  asset_tags: string[];
  topic_tags: string[];
  sentiment_score: number;
  sentiment_label: 'positive' | 'negative' | 'neutral';
  impact_score: number;
  relevance_score: number;
}

export interface WhaleTransaction {
  id: string;
  symbol: string;
  amount: number;
  amount_usd: number;
  from_address?: string;
  to_address?: string;
  from_exchange?: string;
  to_exchange?: string;
  transaction_type: 'inflow' | 'outflow' | 'transfer';
  timestamp: string;
  blockchain: string;
}

export interface ExchangeFlow {
  exchange: string;
  symbol: string;
  inflow: number;
  outflow: number;
  netflow: number;
  inflow_usd: number;
  outflow_usd: number;
  netflow_usd: number;
  timestamp: string;
}

export interface AgentOutput {
  agent_name: string;
  agent_type: string;
  status: 'running' | 'completed' | 'error';
  confidence: number;
  analysis: string;
  data: Record<string, any>;
  timestamp: string;
  execution_time_ms: number;
}

export interface TradeSignal {
  symbol: string;
  asset_type: string;
  signal: 'buy' | 'sell' | 'hold' | 'strong_buy' | 'strong_sell';
  confidence: number;
  risk_score: number;
  timeframe: string;
  entry_zone: { min: number; max: number };
  stop_loss: number;
  take_profit: number[];
  supporting_evidence: string[];
  opposing_risks: string[];
  thesis: string;
  rationale: string;
  agents_contributed: string[];
  agent_outputs?: AgentOutput[];
  timestamp: string;
  valid_until: string;
}

export interface MarketSentiment {
  overall_score: number;
  label: 'extreme_fear' | 'fear' | 'neutral' | 'greed' | 'extreme_greed';
  crypto_score: number;
  equities_score: number;
  commodities_score: number;
  fear_greed_index: number;
  timestamp: string;
}

export interface GeopoliticalRisk {
  overall_risk: number;
  risk_level: 'low' | 'moderate' | 'elevated' | 'high' | 'severe';
  active_events: Record<string, any>[];
  affected_regions: string[];
  market_impact: string;
  timestamp: string;
}

export interface DashboardData {
  timestamp: string;
  market_sentiment: MarketSentiment;
  top_movers: MarketData[];
  trending_assets: string[];
  latest_news: NewsItem[];
  active_signals: TradeSignal[];
  macro_events: any[];
  whale_activity: WhaleTransaction[];
  geopolitical_risk: GeopoliticalRisk;
  global_data?: Record<string, any>;
  agent_status: Record<string, string>;
}

export interface AssetOverview {
  symbol: string;
  name: string;
  asset_type: string;
  market_data: MarketData;
  technical_analysis?: TechnicalAnalysis;
  news: NewsItem[];
  signals: TradeSignal[];
  related_assets: string[];
  timestamp: string;
}
