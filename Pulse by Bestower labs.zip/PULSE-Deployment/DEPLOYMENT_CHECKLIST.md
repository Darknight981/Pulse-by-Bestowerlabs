# PULSE Deployment Checklist

## Pre-Deployment

### Backend Server Requirements
- [ ] Python 3.9+ installed
- [ ] pip package manager
- [ ] Virtual environment support
- [ ] 2GB+ RAM available
- [ ] 10GB+ disk space
- [ ] Port 8000 (or custom) open
- [ ] SSH access for configuration

### cPanel Requirements (Frontend)
- [ ] cPanel access credentials
- [ ] Domain configured
- [ ] SSL certificate (Let's Encrypt or purchased)
- [ ] File Manager access

---

## Backend Deployment

### Step 1: Upload Files
- [ ] Upload `backend/` folder to server
- [ ] Verify all files uploaded correctly

### Step 2: Environment Setup
- [ ] Copy `.env.example` to `.env`
- [ ] Update SECRET_KEY with secure random string
- [ ] Configure database path
- [ ] Set DEBUG=false for production

### Step 3: Installation
- [ ] Create virtual environment: `python3 -m venv venv`
- [ ] Activate virtual environment: `source venv/bin/activate`
- [ ] Install dependencies: `pip install -r requirements.txt`
- [ ] Create data directory: `mkdir -p data`

### Step 4: Testing
- [ ] Start backend: `./start.sh`
- [ ] Test health endpoint: `curl http://localhost:8000/api/system/health`
- [ ] Verify API docs: `http://localhost:8000/docs`

### Step 5: Production Setup
- [ ] Create systemd service file
- [ ] Enable service: `sudo systemctl enable pulse-backend`
- [ ] Start service: `sudo systemctl start pulse-backend`
- [ ] Check status: `sudo systemctl status pulse-backend`
- [ ] Configure Nginx reverse proxy
- [ ] Setup SSL certificate

---

## Frontend Deployment (cPanel)

### Step 1: Prepare Files
- [ ] Verify `frontend/dist/` contains:
  - [ ] index.html
  - [ ] assets/ folder with JS/CSS
  - [ ] .htaccess file

### Step 2: Upload to cPanel
- [ ] Log in to cPanel
- [ ] Open File Manager
- [ ] Navigate to `public_html`
- [ ] Delete existing files (backup first!)
- [ ] Upload all frontend files

### Step 3: Configure API Endpoint
- [ ] Edit main JS file in `assets/`
- [ ] Update API_BASE_URL to backend server
- [ ] Save changes

### Step 4: Verify
- [ ] Visit domain: `https://yourdomain.com`
- [ ] Check console for errors
- [ ] Test search functionality
- [ ] Verify all panels load

---

## Post-Deployment Verification

### Backend Tests
```bash
# Health check
curl https://api.yourdomain.com/api/system/health

# Search assets
curl "https://api.yourdomain.com/api/assets/search?query=BTC"

# Get asset data
curl https://api.yourdomain.com/api/assets/BTC/overview

# Get signal
curl https://api.yourdomain.com/api/assets/BTC/signal

# Get dashboard
curl https://api.yourdomain.com/api/dashboard
```

### Frontend Tests
- [ ] Dashboard loads without errors
- [ ] Search returns results
- [ ] Asset detail page works
- [ ] Charts display correctly
- [ ] News panel loads
- [ ] Whale monitor works
- [ ] Agent console shows status

### Integration Tests
- [ ] Frontend connects to backend
- [ ] API calls return 200 status
- [ ] No CORS errors in console
- [ ] Data updates in real-time

---

## Troubleshooting

### Backend Issues

**Service won't start**
```bash
# Check logs
sudo journalctl -u pulse-backend -f

# Verify Python version
python3 --version

# Check dependencies
pip list | grep -E "fastapi|uvicorn"
```

**Port already in use**
```bash
# Find process using port 8000
sudo lsof -i :8000

# Kill process
sudo kill -9 <PID>
```

**Permission denied**
```bash
# Fix permissions
sudo chown -R user:user /path/to/backend
chmod +x /path/to/backend/start.sh
```

### Frontend Issues

**404 errors**
- Check .htaccess file exists
- Verify mod_rewrite is enabled
- Check file permissions (644 for files, 755 for directories)

**Blank page**
- Check browser console for JS errors
- Verify API_BASE_URL is correct
- Check network tab for failed requests

**CORS errors**
- Verify backend CORS configuration
- Check that API URL uses HTTPS
- Ensure domain is whitelisted in backend

---

## Security Checklist

- [ ] Changed default SECRET_KEY
- [ ] Using HTTPS for all communications
- [ ] Backend behind firewall
- [ ] Rate limiting enabled
- [ ] No sensitive data in logs
- [ ] Regular backups configured
- [ ] Monitoring alerts set up

---

## Performance Optimization

### Backend
- [ ] Using multiple workers (uvicorn --workers 2)
- [ ] Database queries optimized
- [ ] Caching implemented (Redis optional)
- [ ] API response time < 500ms

### Frontend
- [ ] Assets compressed (gzip)
- [ ] Static files cached
- [ ] Images optimized
- [ ] Lazy loading implemented

---

## Monitoring Setup

### Backend Monitoring
- [ ] Service status check
- [ ] API response time monitoring
- [ ] Error rate tracking
- [ ] Resource usage (CPU, RAM)

### Frontend Monitoring
- [ ] Uptime monitoring
- [ ] Page load time tracking
- [ ] Error tracking (Sentry or similar)
- [ ] User analytics

---

## Backup Strategy

- [ ] Daily database backups
- [ ] Configuration file backups
- [ ] Frontend build artifacts stored
- [ ] Backup restoration tested

---

## Support Contacts

- Technical Issues: Check logs first
- API Problems: Verify data sources
- Frontend Issues: Check browser console

---

## Sign-off

**Deployed by**: _________________  
**Date**: _________________  
**Version**: 1.0.0  
**Status**: ☐ Development  ☐ Staging  ☐ Production

**Verified by**: _________________  
**Date**: _________________
