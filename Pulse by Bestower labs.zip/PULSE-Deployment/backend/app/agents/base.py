"""Base Agent Class - All agents inherit from this"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from datetime import datetime
import asyncio
import logging

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """Base class for all PULSE agents"""
    
    def __init__(self, name: str, agent_type: str):
        self.name = name
        self.agent_type = agent_type
        self.status = "idle"
        self.last_run = None
        self.execution_time_ms = 0
        self.logger = logging.getLogger(f"agent.{name}")
        
    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute agent analysis"""
        start_time = datetime.now()
        self.status = "running"
        
        try:
            result = await self.analyze(context)
            self.status = "completed"
            
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            self.execution_time_ms = int(execution_time)
            self.last_run = datetime.now()
            
            return {
                "agent_name": self.name,
                "agent_type": self.agent_type,
                "status": "completed",
                "confidence": result.get("confidence", 50),
                "analysis": result.get("analysis", ""),
                "data": result.get("data", {}),
                "timestamp": self.last_run,
                "execution_time_ms": self.execution_time_ms
            }
            
        except Exception as e:
            self.status = "error"
            self.logger.error(f"Agent {self.name} error: {e}")
            
            return {
                "agent_name": self.name,
                "agent_type": self.agent_type,
                "status": "error",
                "confidence": 0,
                "analysis": f"Error: {str(e)}",
                "data": {},
                "timestamp": datetime.now(),
                "execution_time_ms": 0
            }
    
    @abstractmethod
    async def analyze(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Override this method in subclasses"""
        pass
    
    def get_status(self) -> Dict[str, Any]:
        """Get agent status"""
        return {
            "name": self.name,
            "type": self.agent_type,
            "status": self.status,
            "last_run": self.last_run,
            "execution_time_ms": self.execution_time_ms
        }
